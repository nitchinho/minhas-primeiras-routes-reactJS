import React from 'react';
import './App.css';
import PaginaInicial from './componentes/PaginaInicial';

const App = () => (
  <div className="App">
    <PaginaInicial />
  </div>
);

export default App;
